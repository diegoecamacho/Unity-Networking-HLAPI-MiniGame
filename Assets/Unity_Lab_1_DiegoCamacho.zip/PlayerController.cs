﻿
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

[RequireComponent(typeof(Rigidbody))]
public class PlayerController : NetworkBehaviour {
	[Header("Player Stats")]

	[SyncVar]
	public float Health = 100;

	public float MovementSpeed;

	 private int MaxHealth = 100;
	[Header("Weapon Variables")]
	public GameObject bulletPrefab;
	public Transform bulletSpawn;


	//Components
	Rigidbody m_rigidbody;
	[SerializeField] Slider playerHealthSlider;

	// Use this for initialization
	void Start () {
		m_rigidbody = GetComponent<Rigidbody>();
		
		
	}

	// Update is called once per frame
	void Update () {

		playerHealthSlider.value = Health / MaxHealth;

		if(!hasAuthority) { return; }

		if (isLocalPlayer)
		{
			HandleInput();
		}
	}

	private void HandleInput()
	{
		Vector3 forward = transform.forward * Input.GetAxisRaw("Vertical") * MovementSpeed;

		transform.Rotate(0, Input.GetAxisRaw("Horizontal") * MovementSpeed, 0);

		m_rigidbody.velocity = forward; // right;

		if (Input.GetKeyDown(KeyCode.Space))
		{
			CmdFire();
		}
	}


	public void TakeDamage(int amount)
	{
		if (!isServer)
		{
			return;
		}

		Health -= amount;

		if (Health <= 0)
		{
			Destroy(gameObject);
		}
	}


	[Command]
	void CmdFire()
	{
		GameObject bullet = (GameObject)Instantiate(bulletPrefab, bulletSpawn.position, Quaternion.identity);

		var bulletRB = bullet.GetComponent<Rigidbody>();
		var bulletScript = bullet.GetComponent<BulletBase>();

		bulletRB.AddForce(transform.forward * bulletScript.BulletSpeed, ForceMode.Impulse);

		Destroy(bullet, bulletScript.BulletLifetime);

		NetworkServer.Spawn(bullet);

	}
}
